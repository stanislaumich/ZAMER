spool backup.log

variable check_result varchar2(100);
declare 
  current_version varchar2(4) := '';
begin
  
  :check_result := '*** OK!!! ***';
  end;

/

print check_result

spool off
exit
