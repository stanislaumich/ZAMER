//---------------------------------------------------------------------------
#include <vcl.h>
#pragma hdrstop
#include "DecoderBroker.h"
#include "Main.h"
//---------------------------------------------------------------------------
#pragma package(smart_init)
#pragma resource "*.dfm"
TForm1 *Form1;
//---------------------------------------------------------------------------
  // Array of formats for displaying the main measured value
  char *MasFormatovRas[4]={"%4.0f", "%4.2f", "%4.1f", "%4.3f"};

//---------------------------------------------------------------------------
int __stdcall DataHandler(int DataType,void *Zapis,void *PContext);
//---------------------------------------------------------------------------
__fastcall TForm1::TForm1(TComponent* Owner) 
    : TForm(Owner)
{
  EstID = false;
  EstIzm = false;
  PDecoder = NULL;
  BStart->Enabled = false;
  BStop->Enabled = false;
  BDisconnect->Enabled = false;
  // ................... to protect shared data
  SostDat_CrSe = new TCriticalSection();

  CBDecoderType->ItemIndex = 0;
  CBDecoderTypeChange(this);
  Temperature = 0;
}
// --------------------- "Open" BUTTON
void __fastcall TForm1::BConnectClick(TObject *Sender)
{
  char ServerAddress[300];
  AnsiString AS;
  struct _ParamComPort ParamComPort;

  PortBase = StrToInt(EPortNumber->Text);
  AS = EServerAddress->Text;
  strcpy(ServerAddress,AS.c_str());
  
  NKan=1;
  PSpecialParametrs = (struct _SpecialParametrs *)calloc(sizeof(struct _SpecialParametrs),1);
  PSpecialParametrs->AveragingFactor = StrToInt (EAveragingFactor->Text); // Data Averaging Coefficient
  PSpecialParametrs->SpeedMeasurementPeriod = 1000; // Period of measurement of speed
  PSpecialParametrs->ComPortNumber = StrToInt(EComPortNumber->Text);
  PSpecialParametrs->MODBUS_DeviceAddress = StrToInt(EUnitNumber->Text);
  UnicodeString US = CBBaudRate->Items->Strings[CBBaudRate->ItemIndex];
  ParamComPort.BaudRate = StrToInt(US);
  ParamComPort.BiteSize = 8;
  ParamComPort.Parity = 0;
  ParamComPort.StopBits = 0;
  PSpecialParametrs->PParamComPort = &ParamComPort;
  PSpecialParametrs->ServerAddress = ServerAddress; // Decoder address on the local network
  PSpecialParametrs->AnotherServerBasePortNumber = PortBase; // The base address of the decoder port
  PSpecialParametrs->EthernetProtocolType = CB_Protocol->ItemIndex;
  // ................... Creating a decoder
  PDecoder = (TDecoder *)DecoderCreate(
                                    NKan,
                                    DecoderType,
                                    DataHandler,
                                    this,
                                    PSpecialParametrs);
  free(PSpecialParametrs);
  // ................... If the decoder could not be created
  if (PDecoder == NULL) {
    Memo1->Lines->Add("The decoder could not be created");
    return;
  }
  //................... Opening a decoder for streaming
  int Kod = DecoderOpen(PDecoder,1);
  if (Kod != 0) {
    Memo1->Lines->Add("Failed to open the decoder");
    return;
  }
  else {
    Memo1->Lines->Add("Decoder is open");
  }
  BConnect->Enabled = false;
  BStart->Enabled = true;
  BStop->Enabled = false;
  BDisconnect->Enabled = true;
}
// --------------------- "Close" BUTTON
void __fastcall TForm1::BStartClick(TObject *Sender)
{
  BConnect->Enabled = false;
  BStart->Enabled = false;
  BStop->Enabled = true;
  BDisconnect->Enabled = true;

  EstIzm = true;                 // Measurement started on the channel
  KolIzmOto = 0;
  ReflectionTimer->Enabled = true;
}
// --------------------- BUTTON "STOP MEASUREMENTS"
void __fastcall TForm1 :: BStopClick (TObject * Sender)
{
  BConnect-> Enabled = false;
  BStart-> Enabled = true;
  BStop-> Enabled = false;
  BDisconnect-> Enabled = true;

  ReflectionTimer-> Enabled = false;
  EstIzm = false; // Channel stopped measuring
}
// --------------------- BUTTON "DISCONNECTING FROM SERVER"
void __fastcall TForm1 :: BDisconnectClick (TObject * Sender)
{
  ReflectionTimer-> Enabled = false;
  EstIzm = false; // Channel stopped measuring
  EstID = false;

  // ................... Closing the decoder
  if (PDecoder != NULL) {
    DecoderClose (PDecoder);
    PDecoder = NULL;
  }
  Memo1-> Lines-> Add ("Decoder is closed");

  BConnect-> Enabled = true;
  BStart-> Enabled = false;
  BStop-> Enabled = false;
  BDisconnect-> Enabled = false;
}
// --------------------- CLOSING THE FORM
void __fastcall TForm1 :: FormClose (TObject * Sender, TCloseAction & Action)
{
  BDisconnectClick (this);
  Action = caFree;
}
// --------------------- DATA PROCESSOR COMING FROM THE DECODER
int __stdcall DataHandler (int DataType, void * PZapis, void * PContext)
{
  struct _DataFrame * PDataFrame;
  TForm1 * PForm1 = (TForm1 *) PContext;

  
  // ................... Processing received data
  switch (DataType) {
  case DATA_TYPE_DATA: // Data type - measurement data
    // ................. If the sensor identifier is not received
    if (! PForm1-> EstID) return 0;
    // ................. If measurements are stopped
    if (! PForm1-> EstIzm) return 0;
    PDataFrame = (struct _DataFrame *) PZapis;
    PForm1-> SostDat_CrSe-> Enter ();
    PForm1-> SummaZn_Osn += PDataFrame-> OsnIzmVel[0];
    PForm1-> KolIzmOto ++;
    PForm1-> Temperature = PDataFrame-> Temper;
    PForm1-> Skorost = PDataFrame-> Skorost;
    PForm1-> Moshn = PDataFrame-> Moschnost;
    PForm1-> SostDat_CrSe-> Leave ();
    break;

  case DATA_TYPE_MESSAGES: // Data type - decoder messages
    struct _MessageFrame * PMessageFrame = (struct _MessageFrame *) PZapis;
    PostMessage (Form1-> Handle, WM_USER + 1, PMessageFrame-> MessageCode, NULL);
    break;
  }
  return 0;
}
// --------------------- PROCESSING THE MESSAGE
void __fastcall TForm1 :: UserMessage (TMessage & msg)
{
  int retkod;
  char * PMessage;
  AnsiString AS;

  char Message1 [] = "Received sensor ID";
  char Message2 [] = "Sync failed";
  char Message3 [] = "Distorting the Identifier";
  char Message4 [] = "Sensor disconnected";
  char Message5 [] = "Sensor connected";
  char Message6 [] = "The decoder is disconnected";
  char Message7 [] = "The decoder is connected";
  char Message8 [] = "Transmission-distortion";
  char Message9 [] = "I / O Error";
  char Message10 [] = "There is no pause in reception";
  char Message11 [] = "No network access";
  char Message12 [] = "Restore Sync";
  char Message13 [] = "There are no messages from the decoder";
  char Message14 [] = "Loss of data buffer during stream reading";
  char Message15 [] = "The message queue was full";
  int Razmernost;
  int DataType;
  int Index;

  DataType = msg.WParam;
  switch (DataType) {
  case MESSAGE_POLUCHEN_ID: // Received Identifier
    // ............... Reading the service channel of the sensor
    retkod = DecoderReadTranducerParametrs (PDecoder, & SK, StrokaDatchikID);
    if (retkod != 0) {
      PMessage = "Could not read service channel";
    }
    else {
      PMessage = Message1;
    }
    // ............... Display the sensor ID
    AS = StrokaDatchikID;
    EDatchikID-> Text = AS;
    // ................... Retrieve data dimension
    Razmernost = SK.ID_Datchik [1] >> 4; // Number 3
    // ................... Calculation of the index for setting display formats
    switch (Razmernost) {
    case 0: case 3: case 6: case 9: case 12:  Index = 0; break;
    case 1: case 4: case 7: case 10: case 14: Index = 1; break;
    case 2: case 5: case 8: case 11: case 13: Index = 2; break;
    case 15: Index = 3; break;
    }
    FormatOtobrajenia = MasFormatovRas [Index];
    EstID = true;
    break;

  case MESSAGE_SBOI_SYNCHRO: // Sync failed
    PMessage = Message2; break;
  case MESSAGE_VOSST_SYNCHRO: // Restore Sync
    PMessage = Message12; break;
  case MESSAGE_OSHIBKA_ID: // Identifier Distortion
    PMessage = Message3; break;
  case MESSAGE_DATCHIK_OFF: // Sensor disconnected
    PMessage = Message4; break;
  case MESSAGE_DATCHIK_ON: // Sensor connected
    PMessage = Message5; break;
  case MESSAGE_DECODER_OFF: // Decoder disconnected
    PMessage = Message6; break;
  case MESSAGE_DECODER_ON: // Decoder connected
    PMessage = Message7; break;
  case MESSAGE_ISKAJENIA: // Transmission-distortion
    PMessage = Message8; break;
  case MESSAGE_OSHIBKA_IO: // I / O Error
    PMessage = Message9; break;
  case MESSAGE_NET_PAUSY: // There is no pause in reception
    PMessage = Message10; break;
  case MESSAGE_NETWORK_OFF: // No network access
    PMessage = Message11; break;
  case MESSAGE_BUFFER_LOSS: // Loss of data buffer during stream reading
    PMessage = Message14; break;
  case MESSAGE_MESSAGEQ_OVERFL: // There was a message queue overflow
    PMessage = Message15; break;
  default:
    PMessage = NULL; break;
  }
  if (PMessage != NULL) {
    Memo1-> Lines-> Add (PMessage);
  }
  return;
}
// --------------------- TIMER PROCESSOR FOR SHOWING VALUES ON THE FORM PANELS
void __fastcall TForm1 :: ReflectionTimerTimer (TObject * Sender)
{
  AnsiString AS;
  float AbsZnachenie;
  float Znachenie;
  int i;

  // ................... If the counter is set to zero
  if (KolIzmOto == 0) return;
  // ................... Wait for the release of the critical section
  SostDat_CrSe-> Enter ();
  // ................... Calculate the average value
  Znachenie = SummaZn_Osn / (double) KolIzmOto; // mean
  SummaZn_Osn = 0;
  KolIzmOto = 0;
  // ................... Leave the critical section
  SostDat_CrSe->Leave ();
  // ................... Display values
  // ................... Formation of a line for displaying the main measurement value in the panel
  STOsnIzmVel->Caption = AS.sprintf (FormatOtobrajenia, Znachenie);
  // ................... Formation of a line for displaying temperature
  if (Temperature < -40) {
    STTemper->Caption = "";
  }
  else {
    STTemper->Caption = AS.sprintf ("% 4.1f", Temperature);
  }
  // ................... Formation of a line for displaying speed on the panel
  if (Skorost < 1000) {
    STSkorost->Caption = AS.sprintf ("% 4.1f", Skorost);
  }
  else {
    STSkorost->Caption = AS.sprintf ("% 4.0f", Skorost);
  }
  // ................... Formation of a line to display power on the panel
  STMoschnost->Caption = AS.sprintf (FormatOtobrajenia, Moshn);
  
}
// --------------------- Clear the display panel
void __fastcall TForm1 :: BClearClick (TObject * Sender)
{
  STOsnIzmVel-> Caption = "";
  STTemper-> Caption = "";
  STSkorost-> Caption = "";
  STMoschnost-> Caption = "";
}
// ------------------------------------------------ ---------------------------
void __fastcall TForm1 :: CBDecoderTypeChange (TObject * Sender)
{
  LComPortNumber-> Enabled = false;
  EComPortNumber-> Enabled = false;
  LBaudRate-> Enabled = false;
  CBBaudRate-> Enabled = false;
  LUnitNumber-> Enabled = false;
  EUnitNumber-> Enabled = false;
  LServerAddress-> Enabled = false;
  EServerAddress-> Enabled = false;
  LPortNumber-> Enabled = false;
  EPortNumber-> Enabled = false;
  CB_Protocol->Enabled = false;
  LProtocol->Enabled = false;

  switch (CBDecoderType-> ItemIndex) {
  case 0: // T25
    DecoderType = USB_DECODER;
    break;
  case 1: // T32
    DecoderType = COMPORT_DECODER_T32;
    LComPortNumber-> Enabled = true;
    EComPortNumber-> Enabled = true;
    LBaudRate-> Enabled = true;
    CBBaudRate-> Enabled = true;
    break;
  case 2: // T35
    DecoderType = USB_DECODER_T35;
    break;
  case 3: // T42 2
    DecoderType = COMPORT_DECODER_T42;
    LComPortNumber-> Enabled = true;
    EComPortNumber-> Enabled = true;
    LBaudRate-> Enabled = true;
    CBBaudRate-> Enabled = true;
    break;
  case 4: // T45
    DecoderType = USB_DECODER_T45;
    break;
  case 5: // Simulator
    DecoderType = SIMULATOR_DECODER;
    break;
  case 6: // T42 indicator (USB)
    DecoderType = USB_INDICATOR;
    break;
  case 7: // T42 indicator (RS-232)
    DecoderType = COMPORT_INDICATOR;
    LComPortNumber-> Enabled = true;
    EComPortNumber-> Enabled = true;
    LBaudRate-> Enabled = true;
    CBBaudRate-> Enabled = true;
    break;
  case 8: // T42 indicator (Ethernet)
    DecoderType = ETHERNET_INDICATOR;
    LServerAddress-> Enabled = true;
    EServerAddress-> Enabled = true;
    LPortNumber-> Enabled = true;
    EPortNumber-> Enabled = true;
    EServerAddress-> Text = "IT42E9";
//  CB_Protocol->Enabled = true;
    LProtocol->Enabled = true;
    break;
  }
}
// ------------------------------------------------ ---------------------------

