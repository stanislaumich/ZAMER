#include "stdafx.h"
#include <stdio.h>
#include <vcclr.h>
#include <shlwapi.h>
#include <queue>
#include "VCDecoder.h"
#include "Form1.h"
//-----------------------------------------------------------------------------
using namespace Example4;
//---------------------------------------------------------------------------
  // Array of formats for displaying the main measured value
  char *MasFormatovRas[4]={"%4.0f", "%4.2f", "%4.1f", "%4.3f"};
  using namespace std;
  queue <char> MessageQueue;

//---------------------------------------------------------------------------
  int __stdcall DataHandler(int DataType,void *Zapis,void *PContext);
  int ClientID;
  void *PDecoder;
  int PortBase;
  int NKan;
  char StrokaDatchikID[10];
  struct _SK SK;
  struct _SpecialParametrs *PSpecialParametrs;
  char *FormatOtobrajenia;
  int DecoderType;
  CRITICAL_SECTION SostDat_CrSe; 
  double SummaZn_Osn; // The sum of the values of the main measured value
  int KolIzmOto; // Number of measurements for averaging data
  float Skorost; // calculated speed
  float Moshn; // calculated power
  float Temperature; // temperature
  bool EstIzm;
  bool EstID;

//-----------------------------------------------------------------------------
Form1::Form1(void)
{
  InitializeComponent();

  EstID = false;
  EstIzm = false;
  PDecoder = NULL;
  BStart->Enabled = false;
  BStop->Enabled = false;
  BDisconnect->Enabled = false;
  //................... Critical section to protect shared data
  InitializeCriticalSection(&SostDat_CrSe);
  CBDecoderType->SelectedIndex = 0;
  CBDecoderTypeChange();
  Temperature = 0;
  Skorost = 0;
  Moshn;
  KolIzmOto = 0;
  SummaZn_Osn = 0;
}
//--------------------- Release all resources used
Form1::~Form1()
{
  if (components) {
	delete components;
  }
}
//-----------------------------------------------------------------------------
void Form1::ConnectClick(void) 
{
  using namespace System;

  pin_ptr<const wchar_t> PtrCWSTR;
  char ServerAddress[300];
  char TempChar[10];
  String ^AS;
  struct _ParamComPort ParamComPort;
  int PortBase;
  struct _SpecialParametrs *PSpecialParametrs;
  
  PtrCWSTR = PtrToStringChars(EPortNumber->Text);
  WideCharToMultiByte(1251, 0, PtrCWSTR, -1, TempChar, 10, NULL, 0);
  PortBase = atoi(TempChar);
  AS = EServerAddress->Text;
  PtrCWSTR = PtrToStringChars(AS);
  WideCharToMultiByte(1251, 0, PtrCWSTR, -1, ServerAddress, 300, NULL, 0);

  BConnect->Enabled = false;
  // ................... Memory request for the structure
  PSpecialParametrs = (struct _SpecialParametrs *) calloc(sizeof(struct _SpecialParametrs), 1);
  // ................... Formation of the AveragingFactor parameter
  PtrCWSTR = PtrToStringChars(EAveragingFactor->Text);
  WideCharToMultiByte(1251, 0, PtrCWSTR, -1, TempChar, 10, NULL, 0);
  PSpecialParametrs->AveragingFactor = atoi(TempChar);
  // ................... Formation of the SpeedMeasurementPeriod parameter
  PSpecialParametrs->SpeedMeasurementPeriod = 1000; // Period of measurement of speed
  // ................... Formation of the ComPortNumber parameter
  PtrCWSTR = PtrToStringChars(EComPortNumber->Text);
  WideCharToMultiByte(1251, 0, PtrCWSTR, -1, TempChar, 10, NULL, 0);
  PSpecialParametrs->ComPortNumber = atoi(TempChar);
  // ................... Formation of the MODBUS_DeviceAddress parameter
  PtrCWSTR = PtrToStringChars(EUnitNumber->Text);
  WideCharToMultiByte(1251, 0, PtrCWSTR, -1, TempChar, 10, NULL, 0);
  PSpecialParametrs->MODBUS_DeviceAddress = atoi(TempChar);
  // ................... Formation of the BaudRate parameter
  AS = CBBaudRate->SelectedItem->ToString();
  PtrCWSTR = PtrToStringChars(AS);
  WideCharToMultiByte(1251, 0, PtrCWSTR, -1, TempChar, 10, NULL, 0);
  ParamComPort.BaudRate = atoi(TempChar);
  // ................... Formation of other parameters of ParamComPort
  ParamComPort.BiteSize = 8;
  ParamComPort.Parity = 0;
  ParamComPort.StopBits = 0;
  PSpecialParametrs->PParamComPort = &ParamComPort;

  PSpecialParametrs->ServerAddress = ServerAddress; // Decoder address on the local network
  PSpecialParametrs->AnotherServerBasePortNumber = PortBase; // The base address of the decoder port
															 //................... Creating a decoder
  PDecoder = DecoderCreate(1, DecoderType, (DATA_HANDLER)DataHandler, NULL, PSpecialParametrs);
  free(PSpecialParametrs);
  //................... Decoder opening
  int Kod = DecoderOpen(PDecoder,1);
  if (Kod != 0) {
	Memo1->AppendText("Could not open decoder\n");
    return;
  }
  else {
    Memo1->AppendText("Decoder open\n");
  }
  //................... Start timer to display received data
  ReflectionTimer->Enabled = true;

  BConnect->Enabled = false;
  BStart->Enabled = true;
  BStop->Enabled = false;
  BDisconnect->Enabled = true;
}
//-----------------------------------------------------------------------------
void Form1::DisconnectClick(void)
{
  ReflectionTimer->Enabled =false;
  EstIzm = false;                // Measurements stopped on the channel
  EstID = false;

  //................... Decoder Close
  if (PDecoder!=NULL) {
    DecoderClose(PDecoder);
    PDecoder = NULL;
  }
  Memo1->AppendText("Decoder is closed\n");

  BConnect->Enabled = true;
  BStart->Enabled = false;
  BStop->Enabled = false;
  BDisconnect->Enabled = false;
}
//-----------------------------------------------------------------------------
System::Void Form1::CBDecoderType_SelectedIndexChanged(System::Object^  sender, System::EventArgs^  e) 
{
  CBDecoderTypeChange();
}
//-----------------------------------------------------------------------------
System::Void Form1::BConnect_Click(System::Object^  sender, System::EventArgs^  e) 
{
  ConnectClick();
}
//-----------------------------------------------------------------------------
System::Void Form1::BDisconnect_Click(System::Object^  sender, System::EventArgs^  e) 
{
  DisconnectClick();
}
//-----------------------------------------------------------------------------
System::Void Form1::BClear_Click(System::Object^  sender, System::EventArgs^  e) 
{
  STOsnIzmVel->Text = "";
  STTemper->Text = "";
  STSkorost->Text = "";
  STMoschnost->Text = "";
}
//-----------------------------------------------------------------------------
System::Void Form1::Form1_FormClosing(System::Object^  sender, System::Windows::Forms::FormClosingEventArgs^  e)
{
  DisconnectClick();
}
//-----------------------------------------------------------------------------
System::Void Form1::BStart_Click(System::Object^  sender, System::EventArgs^  e) 
{
  BConnect->Enabled = false;
  BStart->Enabled = false;
  BStop->Enabled = true;
  BDisconnect->Enabled = true;

  EstIzm = true;                 // Measurement started on channel
  KolIzmOto = 0;
}
//-----------------------------------------------------------------------------
System::Void Form1::BStop_Click(System::Object^  sender, System::EventArgs^  e) 
{
  BConnect->Enabled = false;
  BStart->Enabled = true;
  BStop->Enabled = false;
  BDisconnect->Enabled = true;

  ReflectionTimer->Enabled =false;
  EstIzm = false;                 // Measurements stopped on the channel
}
//-----------------------------------------------------------------------------
void Form1::CBDecoderTypeChange(void)
{
  LComPortNumber->Enabled = false;
  EComPortNumber->Enabled = false;
  LBaudRate->Enabled = false;
  CBBaudRate->Enabled = false;
  LUnitNumber->Enabled = false;
  EUnitNumber->Enabled = false;
  LServerAddress->Enabled = false;
  EServerAddress->Enabled = false;
  LPortNumber->Enabled = false;
  EPortNumber->Enabled = false;
  switch (CBDecoderType->SelectedIndex) {
  case 0:  // T25
	  DecoderType = USB_DECODER;
	  break;
  case 1:  // T32
	  DecoderType = COMPORT_DECODER_T32;
	  LComPortNumber->Enabled = true;
	  EComPortNumber->Enabled = true;
	  LBaudRate->Enabled = true;
	  CBBaudRate->Enabled = true;
	  break;
  case 2:  // T35
	  DecoderType = USB_DECODER_T35;
	  break;
  case 3:  // T37
	  DecoderType = ETHERNET_DECODER_T37;
	  LServerAddress->Enabled = true;
	  EServerAddress->Enabled = true;
	  LPortNumber->Enabled = true;
	  EPortNumber->Enabled = true;
	  break;
  case 4:  // T42
	  DecoderType = COMPORT_DECODER_T42;
	  LComPortNumber->Enabled = true;
	  EComPortNumber->Enabled = true;
	  LBaudRate->Enabled = true;
	  CBBaudRate->Enabled = true;
	  break;
  case 5:  // T45
	  DecoderType = USB_DECODER_T45;
	  break;
  case 6: // Simulator
	  DecoderType = SIMULATOR_DECODER;
	  break;
  case 7:  // Indicator T42(USB)
	  DecoderType = USB_INDICATOR;
	  break;
  case 8:  // Indicator T42(RS-232)
	  DecoderType = COMPORT_INDICATOR;
	  LComPortNumber->Enabled = true;
	  EComPortNumber->Enabled = true;
	  LBaudRate->Enabled = true;
	  CBBaudRate->Enabled = true;
	  break;
  case 9:  // Indicator T(Ethernet)
	  DecoderType = ETHERNET_INDICATOR;
	  LServerAddress->Enabled = true;
	  EServerAddress->Enabled = true;
	  LPortNumber->Enabled = true;
	  EPortNumber->Enabled = true;
	  EServerAddress->Text = "IT42E1";
	  break;
  }
}
//--------------------- ��������� ���������
void Form1::MessageHandler(int MessageCode)
{
  int retkod;
  char *PMessage;
  int Razmernost;
  int Index;

  char Message1[] = "Received sensor ID";
  char Message2[] = "Sync failed";
  char Message3[] = "Distorting the Identifier";
  char Message4[] = "Sensor disconnected";
  char Message5[] = "Sensor connected";
  char Message6[] = "The decoder is disconnected";
  char Message7[] = "The decoder is connected";
  char Message8[] = "Transmission distortion";
  char Message9[] = "I/O Error";
  char Message10[] = "There is no pause in reception";
  char Message11[] = "No network access";
  char Message12[] = "Restore Sync";
  char Message13[] = "There are no messages from the decoder";
  char Message14[] = "Loss of data buffer during stream reading";
  char Message15[] = "The message queue was full";

  switch (MessageCode) {
  case MESSAGE_POLUCHEN_ID:    // Received sensor ID
    //............... Reading the service channel of the sensor
    retkod = DecoderReadTranducerParametrs(PDecoder,&SK,StrokaDatchikID);
    if (retkod != 0) {
      Memo1->AppendText("Failed to read service channel\n");
      return;
    }
    PMessage = Message1;
    //............... Sensor ID Display
    EDatchikID->Text = gcnew String(StrokaDatchikID);
    //............... Extract data dimension
    Razmernost = SK.ID_Datchik[1]>>4;    // Numeral 3 
    //............... Index calculation for setting display formats
    switch (Razmernost) {
      case 0: case 3: case 6: case 9: case 12:  Index=0; break;
      case 1: case 4: case 7: case 10: case 14: Index=1; break;
      case 2: case 5: case 8: case 11: case 13: Index=2; break;
      case 15:                                  Index=3; break;
    }
    FormatOtobrajenia = MasFormatovRas[Index];
    EstID = true;
    break;
  case MESSAGE_SBOI_SYNCHRO:   // Sync failed
	PMessage = Message2;  break;
  case MESSAGE_VOSST_SYNCHRO:  // Distorting the Identifier
    PMessage = Message12;  break;
  case MESSAGE_OSHIBKA_ID:     // Distorting the Identifier
    PMessage = Message3;  break;
  case MESSAGE_DATCHIK_OFF:    // Sensor disconnected
    PMessage = Message4;  break;
  case MESSAGE_DATCHIK_ON:     // Sensor connected
    PMessage = Message5;  break;
  case MESSAGE_DECODER_OFF:    // The decoder is disconnected
    PMessage = Message6;  break;
  case MESSAGE_DECODER_ON:     // The decoder is connected
    PMessage = Message7;  break;
  case MESSAGE_ISKAJENIA:      // Transmission distortion
    PMessage = Message8;  break;
  case MESSAGE_OSHIBKA_IO:     // I/O Error
    PMessage = Message9;  break;
  case MESSAGE_NET_PAUSY:      // There is no pause in reception
    PMessage = Message10;  break;
  case MESSAGE_NETWORK_OFF:    // No network access
    PMessage = Message11;  break;
  case MESSAGE_BUFFER_LOSS:    // Loss of data buffer during stream reading
    PMessage = Message14;  break;
  case MESSAGE_MESSAGEQ_OVERFL:   // The message queue was full
    PMessage = Message15;  break;
  default:
    PMessage = NULL;  break;
  }
  if (PMessage != NULL) {
    String ^S = gcnew String(PMessage);
    S = L"Read message \"" + S + L"\"\n";
    Memo1->AppendText(S);
  }
  return;
}
//--------------------- DATA PROCESSOR COMING FROM THE DECODER
int __stdcall DataHandler(int DataType,  void *PZapis, void *PContext)
{
  struct _DataFrame *PDataFrame;
  struct _MessageFrame *PMessageFrame;

  //................... Processing Received Data
  switch (DataType) {
  case DATA_TYPE_DATA:   // Data Type - Measurement Data
    //................. If no sensor ID is received
    if (!EstID) return 0;    
    //................. If measurements are stopped
    if (!EstIzm) return 0; 
    PDataFrame = (struct _DataFrame *)PZapis;
    //................. Wait for the release of the critical section
    EnterCriticalSection(&SostDat_CrSe);
    SummaZn_Osn += PDataFrame->OsnIzmVel[0];
    KolIzmOto++;
    Temperature = PDataFrame->Temper;
    Skorost = PDataFrame->Skorost;
    Moshn = PDataFrame->Moschnost;
    //................. Leave critical section
    LeaveCriticalSection(&SostDat_CrSe);
    break;

  case DATA_TYPE_MESSAGES: // Data Type - Decoder Messages
    PMessageFrame = (struct _MessageFrame *)PZapis;
    //................. Wait for the release of the critical section
    EnterCriticalSection(&SostDat_CrSe);
    //................. Add message to queue
	MessageQueue.push(PMessageFrame->MessageCode);
    //................. Leave critical section
    LeaveCriticalSection(&SostDat_CrSe);
    break;
  }
  return 0;
}
//---------------------------------------------------------------------------
System::Void Form1::ReflectionTimer_Tick(System::Object^  sender, System::EventArgs^  e)
{
  using namespace std;

  double Znachenie;
  char TempChar[10];
  char MessageCode;
  int i, MessageCount;

  //................... Wait for the release of the critical section
  EnterCriticalSection(&SostDat_CrSe); 
  //................... Message Display
  MessageCount = MessageQueue.size();
  for (i=0; i<MessageCount; i++) {
    //................. Take a message from the queue
	MessageCode = (char)MessageQueue.front();
    MessageHandler(MessageCode);
	MessageQueue.pop();
  }
  //................... If the average counter is zero
  if (KolIzmOto == 0) goto ErrExit;
  //................... Calculate average
  Znachenie = SummaZn_Osn/KolIzmOto;    // Average
  SummaZn_Osn=0;
  KolIzmOto=0;
  //................... Leave critical section
  LeaveCriticalSection(&SostDat_CrSe); 
  //................... Value Display
  //................... Formation of a line to display the main measurement value in the panel
  sprintf_s(TempChar, FormatOtobrajenia, Znachenie);
  STOsnIzmVel->Text = gcnew String(TempChar);
  //................... Formation of a line for displaying temperature
  if (Temperature < -40) {
    STTemper->Text = L"";
  }
  else {
    sprintf_s(TempChar, "%4.1f", Temperature);
    STTemper->Text = gcnew String(TempChar);
  }
  //................... Formation of a line for displaying speed on the panel
  if (Skorost < 1000) {
    sprintf_s(TempChar, "%4.1f", Skorost);
  }
  else {
    sprintf_s(TempChar, "%4.0f", Skorost);
  }
  STSkorost->Text = gcnew String(TempChar);
  //................... Formation of a line for displaying power on the panel
  sprintf_s(TempChar, FormatOtobrajenia, Moshn);
  STMoschnost->Text = gcnew String(TempChar);
  return;
ErrExit:
  //................... Leave critical section
  LeaveCriticalSection(&SostDat_CrSe); 
}
//-----------------------------------------------------------------------------
